/* fonts */
export const FontFamily = {
  leftAlignedDarkLabel: "SF Pro Display",
  rubikMedium: "Rubik-Medium",
  rubikRegular: "Rubik-Regular",
};
/* font sizes */
export const FontSize = {
  leftAlignedDarkDisplay_size: 14,
  leftAlignedDarkLabel_size: 12,
  leftAlignedDarkH3_size: 16,
};
/* Colors */
export const Color = {
  colorBlack: "#000",
  color3100: "#1e1f20",
  color420: "rgba(255, 255, 255, 0.2)",
  color4100: "#fff",
  colorMediumslateblue_100: "#7265e3",
  color1100: "#0659fd",
  color5100: "#8f92a1",
  colorLightslategray_100: "rgba(143, 146, 161, 0.2)",
  colorSteelblue: "#4c5980",
  colorDarkslategray: "#2d3142",
};
/* border radiuses */
export const Border = {
  br_11xs_3: 1,
  br_10xs_7: 3,
  br_4xs: 9,
  br_xs: 12,
  br_81xl: 100,
  br_13xl: 32,
  br_5xs: 8,
  br_9xs: 4,
  br_base: 16,
};
