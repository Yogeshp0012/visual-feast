import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, FontFamily, Color, FontSize } from "../GlobalStyles";

const Home = () => {
  return (
    <View style={styles.home}>
      <View style={[styles.cards, styles.mainPosition]}>
        <View style={[styles.card02, styles.card02Position]}>
          <View style={styles.background} />
          <View style={[styles.share, styles.shareLayout]}>
            <View style={[styles.miscchipIcon, styles.iconPosition1]}>
              <View style={[styles.rectangle, styles.rectangleLayout]} />
              <Text style={[styles.label, styles.labelTypo]}>Share</Text>
              <Image
                style={styles.iconshare}
                contentFit="cover"
                source={require("../assets/iconshare.png")}
              />
            </View>
          </View>
          <View style={[styles.comments, styles.shareLayout]}>
            <View style={[styles.miscchipIcon, styles.iconPosition1]}>
              <View style={[styles.rectangle, styles.rectangleLayout]} />
              <Text style={[styles.label1, styles.labelTypo]}>148</Text>
              <Image
                style={[styles.iconcomment, styles.imageIconLayout]}
                contentFit="cover"
                source={require("../assets/iconcomment.png")}
              />
            </View>
          </View>
          <View style={[styles.likes, styles.shareLayout]}>
            <View style={[styles.miscchipIcon, styles.iconPosition1]}>
              <View style={[styles.rectangle, styles.rectangleLayout]} />
              <Text style={[styles.label2, styles.labelTypo]}>326</Text>
              <Image
                style={[styles.iconheartregular, styles.imageIconLayout]}
                contentFit="cover"
                source={require("../assets/iconheartregular.png")}
              />
            </View>
          </View>
          <View style={styles.gallery}>
            <View style={[styles.photo3, styles.photo3Position]}>
              <Image
                style={[styles.photo3Icon, styles.iconLayout3]}
                contentFit="cover"
                source={require("../assets/photo-3.png")}
              />
              <View style={[styles.chipchipIcon, styles.shareLayout]}>
                <View style={[styles.miscchipIcon, styles.iconPosition1]}>
                  <View style={[styles.rectangle3, styles.rectangleLayout]} />
                  <Text style={[styles.label3, styles.labelTypo]}>17</Text>
                  <Image
                    style={[styles.iconcamera, styles.imageIconLayout]}
                    contentFit="cover"
                    source={require("../assets/iconcamera.png")}
                  />
                </View>
              </View>
            </View>
            <Image
              style={[styles.photo2Icon, styles.iconLayout3]}
              contentFit="cover"
              source={require("../assets/photo-2.png")}
            />
            <Image
              style={[styles.photo1Icon, styles.iconLayout3]}
              contentFit="cover"
              source={require("../assets/photo-1.png")}
            />
          </View>
          <Text style={[styles.copy, styles.copyTypo]}>
            Whether its a driving tour 😂
          </Text>
          <View style={styles.top}>
            <Image
              style={[styles.optionsIcon, styles.iconLayout]}
              contentFit="cover"
              source={require("../assets/options.png")}
            />
            <View style={[styles.user, styles.iconPosition1]}>
              <View style={[styles.name, styles.namePosition]}>
                <Text style={[styles.timestamp, styles.timestampTypo]}>
                  5min ago
                </Text>
                <Text style={[styles.name1, styles.namePosition]}>
                  Dustin Houston
                </Text>
              </View>
              <Image
                style={[styles.avatarimageIcon, styles.iconLayout]}
                contentFit="cover"
                source={require("../assets/avatarimage.png")}
              />
            </View>
          </View>
        </View>
        <View style={[styles.cardmobile, styles.card02Position]}>
          <View style={styles.background} />
          <View style={[styles.share, styles.shareLayout]}>
            <View style={[styles.miscchipIcon, styles.iconPosition1]}>
              <View style={[styles.rectangle, styles.rectangleLayout]} />
              <Text style={[styles.label, styles.labelTypo]}>Share</Text>
              <Image
                style={styles.iconshare}
                contentFit="cover"
                source={require("../assets/iconshare.png")}
              />
            </View>
          </View>
          <View style={[styles.comments, styles.shareLayout]}>
            <View style={[styles.miscchipIcon, styles.iconPosition1]}>
              <View style={[styles.rectangle, styles.rectangleLayout]} />
              <Text style={[styles.label1, styles.labelTypo]}>148</Text>
              <Image
                style={[styles.iconcomment, styles.imageIconLayout]}
                contentFit="cover"
                source={require("../assets/iconcomment.png")}
              />
            </View>
          </View>
          <View style={[styles.likes, styles.shareLayout]}>
            <View style={[styles.miscchipIcon, styles.iconPosition1]}>
              <View style={[styles.rectangle, styles.rectangleLayout]} />
              <Text style={[styles.label2, styles.labelTypo]}>326</Text>
              <Image
                style={[styles.iconheartregular, styles.imageIconLayout]}
                contentFit="cover"
                source={require("../assets/iconheartregular.png")}
              />
            </View>
          </View>
          <View style={styles.gallery}>
            <View style={[styles.photo3, styles.photo3Position]}>
              <Image
                style={[styles.photo3Icon, styles.iconLayout3]}
                contentFit="cover"
                source={require("../assets/photo-3.png")}
              />
              <View style={[styles.chipchipIcon, styles.shareLayout]}>
                <View style={[styles.miscchipIcon, styles.iconPosition1]}>
                  <View style={[styles.rectangle3, styles.rectangleLayout]} />
                  <Text style={[styles.label3, styles.labelTypo]}>17</Text>
                  <Image
                    style={[styles.iconcamera, styles.imageIconLayout]}
                    contentFit="cover"
                    source={require("../assets/iconcamera.png")}
                  />
                </View>
              </View>
            </View>
            <Image
              style={[styles.photo2Icon, styles.iconLayout3]}
              contentFit="cover"
              source={require("../assets/photo-2.png")}
            />
            <Image
              style={[styles.photo1Icon, styles.iconLayout3]}
              contentFit="cover"
              source={require("../assets/photo-1.png")}
            />
          </View>
          <Text style={[styles.copy, styles.copyTypo]}>
            Whether its a driving tour 😂
          </Text>
          <View style={styles.top}>
            <Image
              style={[styles.optionsIcon, styles.iconLayout]}
              contentFit="cover"
              source={require("../assets/options.png")}
            />
            <View style={[styles.user, styles.iconPosition1]}>
              <View style={[styles.name, styles.namePosition]}>
                <Text style={[styles.timestamp, styles.timestampTypo]}>
                  5 min ago
                </Text>
                <Text style={[styles.name1, styles.namePosition]}>
                  Dustin Houston
                </Text>
              </View>
              <Image
                style={[styles.avatarimageIcon, styles.iconLayout]}
                contentFit="cover"
                source={require("../assets/avatarimage1.png")}
              />
            </View>
          </View>
        </View>
      </View>
      <View style={styles.bottomNav01}>
        <View style={[styles.miscchipIcon, styles.iconPosition1]}>
          <View style={[styles.bottomNavBackground, styles.iconPosition1]} />
          <View style={[styles.icons, styles.mainPosition]}>
            <Image
              style={[styles.icon, styles.iconPosition]}
              contentFit="cover"
              source={require("../assets/5.png")}
            />
            <Image
              style={[styles.icon1, styles.iconPosition]}
              contentFit="cover"
              source={require("../assets/4.png")}
            />
            <Image
              style={[styles.icon2, styles.iconPosition]}
              contentFit="cover"
              source={require("../assets/3.png")}
            />
            <Image
              style={[styles.icon3, styles.iconPosition]}
              contentFit="cover"
              source={require("../assets/2.png")}
            />
            <Image
              style={[styles.icon4, styles.iconPosition]}
              contentFit="cover"
              source={require("../assets/1.png")}
            />
          </View>
          <View style={styles.iphoneXhomeIndicatorhomeI}>
            <View style={styles.iphoneXhomeIndicatorhomeIChild} />
          </View>
        </View>
      </View>
      <View style={[styles.profile1, styles.profilePosition]}>
        <View style={[styles.border, styles.borderPosition]} />
        <Image
          style={[styles.imageIcon, styles.imageIconLayout]}
          contentFit="cover"
          source={require("../assets/image.png")}
        />
      </View>
      <View style={[styles.profile2, styles.profilePosition]}>
        <View style={[styles.border, styles.borderPosition]} />
        <Image
          style={[styles.imageIcon, styles.imageIconLayout]}
          contentFit="cover"
          source={require("../assets/image1.png")}
        />
      </View>
      <View style={[styles.profile11, styles.profilePosition]}>
        <View style={[styles.border2, styles.borderPosition]} />
        <Image
          style={[styles.imageIcon, styles.imageIconLayout]}
          contentFit="cover"
          source={require("../assets/image2.png")}
        />
      </View>
      <View style={[styles.profile3, styles.profilePosition]}>
        <View style={[styles.border2, styles.borderPosition]} />
        <Image
          style={[styles.imageIcon, styles.imageIconLayout]}
          contentFit="cover"
          source={require("../assets/image3.png")}
        />
      </View>
      <View style={[styles.profile12, styles.profilePosition]}>
        <View style={[styles.border, styles.borderPosition]} />
        <Image
          style={[styles.imageIcon, styles.imageIconLayout]}
          contentFit="cover"
          source={require("../assets/image4.png")}
        />
      </View>
      <View style={[styles.profile13, styles.profilePosition]}>
        <View style={[styles.border, styles.borderPosition]} />
        <Image
          style={[styles.imageIcon, styles.imageIconLayout]}
          contentFit="cover"
          source={require("../assets/image1.png")}
        />
      </View>
      <View style={[styles.profile14, styles.profilePosition]}>
        <View style={[styles.border, styles.borderPosition]} />
        <Image
          style={[styles.imageIcon, styles.imageIconLayout]}
          contentFit="cover"
          source={require("../assets/image5.png")}
        />
      </View>
      <Image
        style={[styles.addStoryIcon, styles.profilePosition]}
        contentFit="cover"
        source={require("../assets/add-story.png")}
      />
      <View style={[styles.title, styles.mainPosition]}>
        <Text style={[styles.featuredStories, styles.screenTitleTypo]}>
          Featured Stories
        </Text>
      </View>
      <View
        style={[styles.navigationheader01, styles.headerBackgroundPosition]}
      >
        <View
          style={[styles.headerBackground, styles.headerBackgroundPosition]}
        />
        <View style={[styles.main, styles.iconLayout]}>
          <Image
            style={[styles.notificationIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/notification.png")}
          />
          <Image
            style={[styles.leftButtonIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/left-button.png")}
          />
          <Text style={[styles.screenTitle, styles.timeTypo]}>Home</Text>
        </View>
        <View
          style={[styles.iphoneXstatusBarsstatusBa, styles.batteryPosition]}
        >
          <View style={[styles.rectangle8, styles.iconPosition1]} />
          <View style={styles.batteryParent}>
            <View style={[styles.battery, styles.batteryPosition]}>
              <View style={[styles.border7, styles.batteryPosition]} />
              <Image
                style={styles.capIcon}
                contentFit="cover"
                source={require("../assets/cap.png")}
              />
              <View style={styles.capacity} />
            </View>
            <Image
              style={styles.wifiIcon}
              contentFit="cover"
              source={require("../assets/wifi.png")}
            />
            <Image
              style={styles.cellularConnectionIcon}
              contentFit="cover"
              source={require("../assets/cellular-connection.png")}
            />
          </View>
          <View style={styles.timeStyle}>
            <Text style={[styles.time, styles.timeTypo]}>
              <Text style={styles.text}>9:4</Text>1
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  mainPosition: {
    left: 28,
    overflow: "hidden",
  },
  card02Position: {
    left: "0%",
    height: "44.88%",
    right: "0%",
    width: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  shareLayout: {
    height: 30,
    position: "absolute",
  },
  iconPosition1: {
    height: "100%",
    bottom: "0%",
    left: "0%",
  },
  rectangleLayout: {
    opacity: 0.2,
    borderRadius: Border.br_9xs,
    height: "100%",
    left: "0%",
    right: "0%",
    width: "100%",
    position: "absolute",
  },
  labelTypo: {
    textAlign: "left",
    fontFamily: FontFamily.leftAlignedDarkLabel,
  },
  imageIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  photo3Position: {
    left: "71.73%",
    width: "28.27%",
    height: "46.88%",
    right: "0%",
  },
  iconLayout3: {
    borderRadius: Border.br_5xs,
    maxHeight: "100%",
    maxWidth: "100%",
    top: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  copyTypo: {
    color: Color.color5100,
    textAlign: "left",
    fontFamily: FontFamily.leftAlignedDarkLabel,
    position: "absolute",
  },
  iconLayout: {
    height: 38,
    position: "absolute",
  },
  namePosition: {
    marginTop: -20,
    top: "50%",
    position: "absolute",
  },
  timestampTypo: {
    fontSize: FontSize.leftAlignedDarkLabel_size,
    lineHeight: 20,
  },
  iconPosition: {
    marginTop: -19,
    height: 38,
    width: 38,
    top: "50%",
    position: "absolute",
  },
  profilePosition: {
    width: 48,
    bottom: "68.6%",
    position: "absolute",
  },
  borderPosition: {
    borderWidth: 2,
    borderStyle: "solid",
    borderRadius: Border.br_xs,
    bottom: "0%",
    top: "0%",
    height: "100%",
    left: "0%",
    right: "0%",
    width: "100%",
    position: "absolute",
  },
  screenTitleTypo: {
    fontWeight: "700",
    color: Color.color3100,
  },
  headerBackgroundPosition: {
    height: 128,
    top: 0,
    left: 0,
    right: 0,
    position: "absolute",
  },
  timeTypo: {
    textAlign: "center",
    fontFamily: FontFamily.leftAlignedDarkLabel,
    top: "50%",
    position: "absolute",
  },
  batteryPosition: {
    top: 0,
    position: "absolute",
  },
  background: {
    backgroundColor: Color.color4100,
    borderRadius: Border.br_xs,
    bottom: "0%",
    top: "0%",
    height: "100%",
    left: "0%",
    right: "0%",
    width: "100%",
    position: "absolute",
  },
  rectangle: {
    bottom: "0%",
    top: "0%",
  },
  label: {
    left: "13.73%",
    color: Color.color3100,
    textAlign: "left",
    fontFamily: FontFamily.leftAlignedDarkLabel,
    fontWeight: "500",
    lineHeight: 20,
    fontSize: FontSize.leftAlignedDarkDisplay_size,
    top: "50%",
    marginTop: -10,
    position: "absolute",
  },
  iconshare: {
    top: 8,
    left: 50,
    width: 14,
    height: 14,
    position: "absolute",
  },
  miscchipIcon: {
    bottom: "0%",
    top: "0%",
    right: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  share: {
    width: 75,
    right: 18,
    top: 294,
    height: 30,
  },
  label1: {
    left: "39.68%",
    color: Color.color3100,
    textAlign: "left",
    fontFamily: FontFamily.leftAlignedDarkLabel,
    fontWeight: "500",
    lineHeight: 20,
    fontSize: FontSize.leftAlignedDarkDisplay_size,
    top: "50%",
    marginTop: -10,
    position: "absolute",
  },
  iconcomment: {
    width: "22.22%",
    right: "69.84%",
    left: "7.94%",
    bottom: "26.67%",
    top: "26.67%",
    maxWidth: "100%",
    height: "46.67%",
  },
  comments: {
    left: 93,
    width: 63,
    top: 294,
    height: 30,
  },
  label2: {
    left: "39.69%",
    color: Color.color3100,
    textAlign: "left",
    fontFamily: FontFamily.leftAlignedDarkLabel,
    fontWeight: "500",
    lineHeight: 20,
    fontSize: FontSize.leftAlignedDarkDisplay_size,
    top: "50%",
    marginTop: -10,
    position: "absolute",
  },
  iconheartregular: {
    width: "21.54%",
    right: "69.23%",
    left: "9.23%",
    bottom: "26.67%",
    top: "26.67%",
    maxWidth: "100%",
    height: "46.67%",
  },
  likes: {
    width: 65,
    left: 18,
    top: 294,
    height: 30,
  },
  photo3Icon: {
    bottom: "0%",
    height: "100%",
    left: "0%",
    right: "0%",
    width: "100%",
  },
  rectangle3: {
    top: "-3.33%",
    bottom: "3.33%",
  },
  label3: {
    marginTop: -11,
    left: "53.7%",
    color: Color.color4100,
    textAlign: "left",
    fontFamily: FontFamily.leftAlignedDarkLabel,
    fontWeight: "500",
    lineHeight: 20,
    fontSize: FontSize.leftAlignedDarkDisplay_size,
    top: "50%",
    position: "absolute",
  },
  iconcamera: {
    width: "25.93%",
    top: "23.33%",
    right: "55.56%",
    bottom: "30%",
    left: "18.52%",
    height: "46.67%",
    maxWidth: "100%",
  },
  chipchipIcon: {
    marginTop: -14.5,
    marginLeft: -27,
    width: 54,
    left: "50%",
    top: "50%",
  },
  photo3: {
    top: "53.13%",
    bottom: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  photo2Icon: {
    bottom: "53.13%",
    left: "71.73%",
    width: "28.27%",
    height: "46.88%",
    right: "0%",
  },
  photo1Icon: {
    width: "68.2%",
    right: "31.8%",
    bottom: "0%",
    height: "100%",
    left: "0%",
  },
  gallery: {
    top: 116,
    bottom: 66,
    left: 18,
    right: 18,
    position: "absolute",
    overflow: "hidden",
  },
  copy: {
    top: 76,
    width: 290,
    lineHeight: 22,
    left: 18,
    fontSize: FontSize.leftAlignedDarkDisplay_size,
  },
  optionsIcon: {
    width: 38,
    top: 1,
    height: 38,
    right: 0,
  },
  timestamp: {
    marginTop: 0,
    left: 0,
    color: Color.color5100,
    textAlign: "left",
    fontFamily: FontFamily.leftAlignedDarkLabel,
    position: "absolute",
    top: "50%",
  },
  name1: {
    left: 0,
    textAlign: "left",
    fontFamily: FontFamily.leftAlignedDarkLabel,
    color: Color.color3100,
    fontWeight: "500",
    lineHeight: 20,
    fontSize: FontSize.leftAlignedDarkDisplay_size,
  },
  name: {
    left: 46,
    width: 94,
    height: 40,
    overflow: "hidden",
  },
  avatarimageIcon: {
    left: 0,
    width: 38,
    top: 1,
    height: 38,
  },
  user: {
    width: "49.47%",
    right: "50.53%",
    bottom: "0%",
    top: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  top: {
    height: "11.7%",
    top: "5.26%",
    bottom: "83.04%",
    left: 18,
    right: 18,
    position: "absolute",
    overflow: "hidden",
  },
  card02: {
    top: "47.24%",
    bottom: "7.87%",
  },
  cardmobile: {
    bottom: "55.12%",
    top: "0%",
  },
  cards: {
    height: "93.84%",
    top: "35.96%",
    bottom: "-29.8%",
    right: 28,
    left: 28,
    position: "absolute",
  },
  bottomNavBackground: {
    borderTopLeftRadius: Border.br_13xl,
    borderTopRightRadius: Border.br_13xl,
    backgroundColor: Color.color1100,
    bottom: "0%",
    top: "0%",
    right: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  icon: {
    marginLeft: 121.5,
    left: "50%",
  },
  icon1: {
    marginLeft: 51.5,
    left: "50%",
  },
  icon2: {
    marginLeft: -19.5,
    left: "50%",
  },
  icon3: {
    marginLeft: -89.5,
    left: "50%",
  },
  icon4: {
    marginLeft: -159.5,
    left: "50%",
  },
  icons: {
    height: "31.15%",
    top: "20.49%",
    bottom: "48.36%",
    right: 28,
    left: 28,
    position: "absolute",
  },
  iphoneXhomeIndicatorhomeIChild: {
    marginLeft: -66.5,
    bottom: 9,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.color420,
    width: 134,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  iphoneXhomeIndicatorhomeI: {
    top: 88,
    height: 34,
    left: 0,
    position: "absolute",
    width: 375,
  },
  bottomNav01: {
    height: "15.02%",
    top: "84.98%",
    shadowColor: "rgba(163, 163, 164, 0.1)",
    shadowRadius: 60,
    elevation: 60,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: -2,
    },
    bottom: "0%",
    left: "0%",
    right: "0%",
    width: "100%",
    position: "absolute",
  },
  border: {
    borderColor: Color.color1100,
  },
  imageIcon: {
    height: "83.33%",
    width: "83.33%",
    top: "8.33%",
    right: "8.33%",
    bottom: "8.33%",
    left: "8.33%",
    borderRadius: Border.br_4xs,
  },
  profile1: {
    left: 358,
    elevation: 4,
    shadowRadius: 4,
    shadowColor: "rgba(247, 247, 247, 0.8)",
    top: "25.49%",
    height: "5.91%",
    width: 48,
    bottom: "68.6%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: -2,
    },
  },
  profile2: {
    left: 424,
    elevation: 4,
    shadowRadius: 4,
    shadowColor: "rgba(247, 247, 247, 0.8)",
    top: "25.49%",
    height: "5.91%",
    width: 48,
    bottom: "68.6%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: -2,
    },
  },
  border2: {
    borderColor: Color.colorLightslategray_100,
  },
  profile11: {
    left: 292,
    elevation: 4,
    shadowRadius: 4,
    shadowColor: "rgba(247, 247, 247, 0.8)",
    top: "25.49%",
    height: "5.91%",
    width: 48,
    bottom: "68.6%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: -2,
    },
  },
  profile3: {
    left: 490,
    elevation: 4,
    shadowRadius: 4,
    shadowColor: "rgba(247, 247, 247, 0.8)",
    top: "25.49%",
    height: "5.91%",
    width: 48,
    bottom: "68.6%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: -2,
    },
  },
  profile12: {
    left: 226,
    elevation: 4,
    shadowRadius: 4,
    shadowColor: "rgba(247, 247, 247, 0.8)",
    top: "25.49%",
    height: "5.91%",
    width: 48,
    bottom: "68.6%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: -2,
    },
  },
  profile13: {
    left: 160,
    elevation: 4,
    shadowRadius: 4,
    shadowColor: "rgba(247, 247, 247, 0.8)",
    top: "25.49%",
    height: "5.91%",
    width: 48,
    bottom: "68.6%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: -2,
    },
  },
  profile14: {
    left: 94,
    elevation: 4,
    shadowRadius: 4,
    shadowColor: "rgba(247, 247, 247, 0.8)",
    top: "25.49%",
    height: "5.91%",
    width: 48,
    bottom: "68.6%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: -2,
    },
  },
  addStoryIcon: {
    height: "6.03%",
    top: "25.37%",
    width: 48,
    bottom: "68.6%",
    maxHeight: "100%",
    left: 28,
  },
  featuredStories: {
    fontSize: FontSize.leftAlignedDarkH3_size,
    width: 120,
    height: 22,
    top: 0,
    position: "absolute",
    left: 0,
    lineHeight: 22,
    textAlign: "left",
    fontFamily: FontFamily.leftAlignedDarkLabel,
  },
  title: {
    height: "2.71%",
    top: "19.21%",
    right: 226,
    bottom: "78.08%",
    position: "absolute",
  },
  headerBackground: {
    backgroundColor: Color.color4100,
  },
  notificationIcon: {
    right: 0,
  },
  leftButtonIcon: {
    left: 0,
  },
  screenTitle: {
    marginTop: -9,
    left: "43.89%",
    letterSpacing: 1,
    textTransform: "uppercase",
    fontWeight: "700",
    color: Color.color3100,
    fontSize: FontSize.leftAlignedDarkLabel_size,
    lineHeight: 20,
  },
  main: {
    top: 67,
    left: 28,
    overflow: "hidden",
    right: 28,
  },
  rectangle8: {
    bottom: "0%",
    top: "0%",
    right: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  border7: {
    right: 2,
    borderRadius: 3,
    borderColor: Color.colorBlack,
    borderWidth: 1,
    width: 22,
    opacity: 0.35,
    height: 11,
    borderStyle: "solid",
    top: 0,
  },
  capIcon: {
    top: 4,
    width: 1,
    height: 4,
    opacity: 0.4,
    right: 0,
    position: "absolute",
  },
  capacity: {
    top: 2,
    right: 4,
    borderRadius: 1,
    backgroundColor: Color.colorBlack,
    width: 18,
    height: 7,
    position: "absolute",
  },
  battery: {
    width: 24,
    height: 11,
    right: 0,
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  cellularConnectionIcon: {
    width: 17,
    height: 11,
  },
  batteryParent: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  text: {
    letterSpacing: 0,
  },
  time: {
    marginTop: -7.5,
    fontWeight: "600",
    color: Color.colorBlack,
    left: 0,
    width: 54,
    fontSize: FontSize.leftAlignedDarkDisplay_size,
  },
  timeStyle: {
    top: 13,
    left: 21,
    height: 21,
    width: 54,
    position: "absolute",
  },
  iphoneXstatusBarsstatusBa: {
    height: 44,
    left: 0,
    right: 0,
    overflow: "hidden",
  },
  navigationheader01: {
    overflow: "hidden",
  },
  home: {
    backgroundColor: "#f7f7f7",
    height: 812,
    overflow: "hidden",
    width: 375,
  },
});

export default Home;
