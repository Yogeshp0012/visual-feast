import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const MomotaroWelcome = () => {
  return (
    <LinearGradient
      style={styles.momotaroWelcome}
      locations={[0, 1]}
      colors={["#f4f6fa", "#fff"]}
    >
      <View style={styles.frame}>
        <Image
          style={styles.frameIcon}
          contentFit="cover"
          source={require("../assets/frame.png")}
        />
        <Text style={styles.welcomeToMomotaroContainer}>
          <Text style={styles.welcomeTo}>{`Welcome to
`}</Text>
          <Text style={styles.momotaro}>Momotaro</Text>
          <Text style={styles.welcomeTo}> UI Kit</Text>
        </Text>
      </View>
      <View style={styles.frame1}>
        <View style={styles.frame2}>
          <View style={styles.frame3}>
            <Text style={styles.theBestUi}>
              The best UI Kit for your next health and fitness project!
            </Text>
            <Image
              style={styles.frameIcon1}
              contentFit="cover"
              source={require("../assets/frame1.png")}
            />
          </View>
          <View style={styles.mainbutton}>
            <View style={styles.mainbuttonChild} />
            <Text style={styles.button}>Get Started</Text>
          </View>
        </View>
        <Text style={styles.alreadyHaveAccountContainer}>
          <Text style={styles.alreadyHaveAccount}>
            <Text style={styles.alreadyHaveAccount1}>
              Already have account?
            </Text>
            <Text style={styles.text}>{` `}</Text>
          </Text>
          <Text style={styles.signIn}>Sign in</Text>
        </Text>
        <View style={styles.frame4} />
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  frameIcon: {
    position: "relative",
    width: 71,
    height: 68,
    overflow: "hidden",
  },
  welcomeTo: {
    color: Color.colorDarkslategray,
  },
  momotaro: {
    color: Color.colorMediumslateblue_100,
  },
  welcomeToMomotaroContainer: {
    fontSize: 28,
    lineHeight: 32,
    fontWeight: "500",
    fontFamily: FontFamily.rubikMedium,
    textAlign: "center",
    width: 241,
    height: 64,
    marginLeft: 2,
    marginTop: 30,
  },
  frame: {
    position: "absolute",
    top: 63,
    left: 66,
    width: 243,
    height: 162,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  theBestUi: {
    fontSize: FontSize.leftAlignedDarkH3_size,
    letterSpacing: 0,
    lineHeight: 28,
    fontFamily: FontFamily.rubikRegular,
    color: Color.colorSteelblue,
    textAlign: "center",
    width: 256,
    height: 56,
    marginLeft: 1,
  },
  frameIcon1: {
    position: "relative",
    width: 433,
    height: 297,
    overflow: "hidden",
    marginTop: 9,
  },
  frame3: {
    width: 433,
    height: 362,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  mainbuttonChild: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_base,
    backgroundColor: Color.colorMediumslateblue_100,
  },
  button: {
    position: "absolute",
    marginTop: -9,
    top: "50%",
    left: "31.44%",
    fontSize: FontSize.leftAlignedDarkH3_size,
    letterSpacing: 0,
    fontWeight: "500",
    fontFamily: FontFamily.rubikMedium,
    color: Color.color4100,
    textAlign: "center",
  },
  mainbutton: {
    width: 250,
    height: 56,
    marginLeft: 1,
    marginTop: 40,
  },
  frame2: {
    width: 433,
    height: 458,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  alreadyHaveAccount1: {
    color: Color.colorSteelblue,
  },
  text: {
    color: "#66688f",
  },
  alreadyHaveAccount: {
    fontFamily: FontFamily.rubikRegular,
  },
  signIn: {
    fontWeight: "500",
    fontFamily: FontFamily.rubikMedium,
    color: Color.colorMediumslateblue_100,
  },
  alreadyHaveAccountContainer: {
    position: "relative",
    fontSize: FontSize.leftAlignedDarkH3_size,
    lineHeight: 14,
    textAlign: "left",
    width: 240,
    height: 14,
    marginTop: 32,
  },
  frame4: {
    width: 233,
    height: 25,
    overflow: "hidden",
    justifyContent: "center",
    alignItems: "flex-start",
    marginTop: 32,
  },
  frame1: {
    position: "absolute",
    top: 241,
    left: -29,
    width: 433,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  momotaroWelcome: {
    position: "relative",
    backgroundColor: "transparent",
    width: 375,
    height: 812,
    overflow: "hidden",
  },
});

export default MomotaroWelcome;
